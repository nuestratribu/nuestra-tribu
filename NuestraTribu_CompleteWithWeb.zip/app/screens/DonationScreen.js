
import React from 'react';
import { View, Text, Button, Linking, StyleSheet } from 'react-native';

export default function DonationScreen() {
  const donationUrl = 'https://www.paypal.com/donate/?hosted_button_id=TU_ID';
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Apoya Nuestra Tribu</Text>
      <Text style={styles.text}>
        Si esta app te está ayudando, agradeceríamos tu aporte.  
        ¡Cada donación, por pequeña que sea, nos permite seguir creciendo!
      </Text>
      <Button
        title="Donar con PayPal"
        onPress={() => Linking.openURL(donationUrl)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, padding:20, justifyContent:'center' },
  title: { fontSize:22, fontWeight:'bold', marginBottom:15, textAlign:'center' },
  text: { fontSize:16, marginBottom:20, textAlign:'center' },
});
