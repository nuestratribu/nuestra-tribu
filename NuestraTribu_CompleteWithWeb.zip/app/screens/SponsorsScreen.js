
import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet, Linking, TouchableOpacity } from 'react-native';

const sponsors = [
  { name: 'Fundación Salud Mental', logo: require('../assets/logo_fundasalud.png'), url: 'https://fundasaludmental.cl' },
  { name: 'Bienestar Colectivo', logo: require('../assets/logo_bienestar.png'), url: 'https://bienestarcolectivo.org' },
];

export default function SponsorsScreen() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Nuestros Patrocinadores</Text>
      {sponsors.map((s, i) => (
        <TouchableOpacity key={i} style={styles.card} onPress={() => Linking.openURL(s.url)}>
          <Image source={s.logo} style={styles.logo} resizeMode="contain"/>
          <Text style={styles.name}>{s.name}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding:20 },
  title: { fontSize:22, fontWeight:'bold', marginBottom:20, textAlign:'center' },
  card: { alignItems:'center', marginBottom:20 },
  logo: { width:120, height:60, marginBottom:10 },
  name: { fontSize:16 },
});
