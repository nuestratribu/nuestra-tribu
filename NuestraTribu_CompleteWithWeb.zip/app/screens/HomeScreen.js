
import React from 'react';
import { ScrollView, Button, StyleSheet, Text } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Bienvenido a Nuestra Tribu</Text>
      {/* ... existing buttons ... */}
      <Button title="Donar" onPress={() => navigation.navigate('Donaciones')} />
      <Button title="Patrocinadores" onPress={() => navigation.navigate('Patrocinadores')} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding:20, paddingBottom:60 },
  title: { fontSize:22, fontWeight:'bold', marginBottom:20, textAlign:'center' },
});
