
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screens/HomeScreen';
import DonationScreen from './screens/DonationScreen';
import SponsorsScreen from './screens/SponsorsScreen';
// ... other imports ...

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Inicio">
        <Stack.Screen name="Inicio" component={HomeScreen} />
        <Stack.Screen name="Donaciones" component={DonationScreen} />
        <Stack.Screen name="Patrocinadores" component={SponsorsScreen} />
        {/* ... other screens ... */}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
